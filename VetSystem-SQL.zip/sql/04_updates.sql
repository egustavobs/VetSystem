UPDATE CLIENTE SET telefone='3897777-0000' WHERE id_cliente=1;
UPDATE PET SET especie='Cachorro', idade=4 WHERE nome='Thor';
UPDATE MEDICAMENTO SET quantidade=quantidade-5 WHERE id_medicamento=1;